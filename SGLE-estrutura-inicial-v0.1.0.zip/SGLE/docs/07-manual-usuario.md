# Manual do usuário — em construção

Este manual será escrito conforme os módulos forem implementados e validados com os perfis reais da escola. Cada procedimento deverá conter objetivo, permissões necessárias, passo a passo e resultado esperado.
