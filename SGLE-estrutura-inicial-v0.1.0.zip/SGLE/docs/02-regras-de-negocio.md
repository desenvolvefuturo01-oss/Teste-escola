# Regras de negócio — SGLE

| Código | Regra |
|---|---|
| RN001 | Solicitações de reserva serão submetidas à coordenação. |
| RN002 | Não poderá haver duas reservas aprovadas sobrepostas no mesmo laboratório. |
| RN003 | Laboratórios bloqueados ou em manutenção não poderão receber reservas. |
| RN004 | Ações relevantes deverão registrar usuário, data/hora e operação. |
| RN005 | Cada computador será cadastrado individualmente e vinculado a um laboratório. |
| RN006 | Periféricos em uso terão identificação e histórico individual; materiais de reposição terão controle de estoque. |
| RN007 | Defeitos identificados deverão permitir o registro de ocorrência e a sugestão de chamado. |
| RN008 | Movimentações de estoque atualizarão o saldo por meio de operações consistentes no banco. |
| RN009 | Inspeções registrarão ambiente, itens verificados, responsável e data. |
| RN010 | Ações serão limitadas conforme o perfil do usuário. |
| RN011 | Cada laboratório terá agenda própria e a coordenação poderá consultar uma visão consolidada. |
| RN012 | Computadores terão código interno, número patrimonial e QR Code único. |
| RN013 | Inspeções poderão ser feitas por checklist geral ou consulta individual via QR Code. |
| RN014 | Atualizações e versões serão informadas manualmente pelo técnico, com data e observações. |
| RN015 | Teclados e mouses instalados serão rastreados individualmente; reposições terão estoque coletivo. |
| RN016 | A sugestão de abertura de chamado não substituirá o registro da ocorrência. |

As regras serão refinadas durante entrevistas e testes com os usuários da escola.
