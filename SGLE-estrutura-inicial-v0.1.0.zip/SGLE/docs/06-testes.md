# Plano inicial de testes

- Navegação e responsividade em desktop, tablet e celular.
- Autenticação: sessão válida, inválida, expirada e encerramento.
- Autorização: cada perfil só executa ações permitidas.
- Reservas: conflito de horário, aprovação, rejeição e cancelamento.
- Patrimônio: unicidade de código, patrimônio e QR Code.
- Estoque: entradas, saídas, saldo insuficiente e concorrência de movimentações.
- Inspeção/manutenção: ocorrência sem chamado e ocorrência com chamado confirmado.
- Segurança: RLS, acesso cruzado, validação de dados e exposição de segredos.

Cada funcionalidade deverá ter critérios de aceite antes de ser considerada concluída.
