# SGLE — Requisitos iniciais

**Versão:** 0.1.0  
**Status:** estrutura inicial; requisitos sujeitos à validação com a escola.

## Objetivo
Centralizar a gestão dos laboratórios escolares, seus agendamentos, equipamentos, inspeções, manutenção e materiais.

## Perfis previstos
- Administrador: configura o sistema e gerencia acessos.
- Coordenação: analisa e aprova solicitações de reserva.
- Professor: consulta disponibilidade e solicita reservas.
- Técnico: administra equipamentos, inspeções, ocorrências, manutenção e movimentações autorizadas.

## Módulos
Painel; mapa escolar; laboratórios; agendamentos; equipamentos; inspeções; manutenção; estoque; relatórios; usuários; configurações.

## Decisões já estabelecidas
- Cada laboratório terá sua própria agenda e haverá uma visão centralizada.
- A escola utilizará períodos fixos configuráveis.
- Reservas de professores dependem de aprovação da coordenação.
- Computadores terão código interno, patrimônio e QR Code exclusivo.
- Inspeções serão híbridas: checklist do ambiente e consulta individual por QR Code.
- Versões de sistema operacional e atualizações serão registradas manualmente.
- Materiais e produtos poderão ser cadastrados conforme a necessidade.
- Defeitos serão registrados; a abertura de chamado será sugerida ao técnico, que confirma.

## Fora do primeiro escopo
Monitoramento automático dos computadores, integração com ferramentas externas e aplicativo nativo. Podem ser avaliados futuramente.
