const pages = {
  inicio: {
    title: 'Visão geral',
    subtitle: 'Acompanhe a situação dos laboratórios e das atividades escolares.',
    content: `
      <div class="welcome-panel"><div><span class="eyebrow">PAINEL DE CONTROLE</span><h2>Bem-vindo ao SGLE</h2><p>Gestão organizada dos espaços, equipamentos e recursos tecnológicos da escola.</p></div><div class="welcome-symbol">SGLE</div></div>
      <div class="section-heading"><div><h3>Resumo do ambiente</h3><p>Os indicadores serão alimentados pelos dados cadastrados no sistema.</p></div></div>
      <div class="stats-grid">
        ${stat('Laboratórios','—','Cadastros ativos','▤')}
        ${stat('Equipamentos','—','Patrimônio registrado','▧')}
        ${stat('Agendamentos','—','Solicitações pendentes','▣')}
        ${stat('Manutenções','—','Chamados em aberto','⚒')}
      </div>
      <div class="content-grid">
        <article class="panel"><div class="panel-title"><div><h3>Acesso rápido</h3><p>Comece pelas áreas principais.</p></div></div><div class="quick-links">
          ${quick('laboratorios','Cadastrar laboratório','Organize os ambientes da escola.')}
          ${quick('equipamentos','Cadastrar equipamento','Registre computadores e periféricos.')}
          ${quick('agendamentos','Consultar agendamentos','Acompanhe solicitações e horários.')}
          ${quick('estoque','Gerenciar materiais','Cadastre produtos e movimentações.')}
        </div></article>
        <article class="panel"><div class="panel-title"><div><h3>Etapas do projeto</h3><p>Construção progressiva do SGLE.</p></div></div><ol class="milestones"><li class="done"><span>01</span><div><strong>Fundação do projeto</strong><small>Estrutura inicial criada</small></div><b>Em andamento</b></li><li><span>02</span><div><strong>Banco de dados</strong><small>Modelagem e segurança</small></div><b>Próxima etapa</b></li><li><span>03</span><div><strong>Cadastros escolares</strong><small>Laboratórios e ambientes</small></div><b>Pendente</b></li></ol></article>
      </div>`
  },
  mapa: basic('Mapa da escola','Representação esquemática dos blocos, pisos, salas e laboratórios.'),
  laboratorios: basic('Laboratórios','Cadastro e gerenciamento dos ambientes escolares.'),
  agendamentos: basic('Agendamentos','Solicitações de reserva, aprovação da coordenação e disponibilidade por período.'),
  equipamentos: basic('Equipamentos','Inventário individual de computadores, patrimônio e periféricos.'),
  inspecoes: basic('Inspeções','Checklists de verificação e inspeções individuais por QR Code.'),
  manutencao: basic('Manutenção','Registro de ocorrências, chamados e histórico técnico.'),
  estoque: basic('Estoque','Cadastro flexível de materiais, produtos, entradas, saídas e saldos.'),
  relatorios: basic('Relatórios','Indicadores e relatórios operacionais do ambiente escolar.'),
  usuarios: basic('Usuários','Gerenciamento de acessos e perfis do sistema.'),
  configuracoes: basic('Configurações','Parâmetros gerais, períodos escolares e preferências do SGLE.')
};

function stat(label,value,description,icon){return `<article class="stat-card"><div class="stat-top"><span>${label}</span><i>${icon}</i></div><strong>${value}</strong><small>${description}</small></article>`}
function quick(page,title,description){return `<a class="quick-link" href="#${page}" data-page="${page}"><span class="quick-arrow">↗</span><div><strong>${title}</strong><small>${description}</small></div></a>`}
function basic(title,description){return {title,subtitle:description,content:`<div class="empty-state"><div class="empty-icon">✦</div><h3>${title}</h3><p>${description}</p><span class="tag">Módulo planejado para implementação</span></div>`}}

export function renderPage(page = location.hash.slice(1) || 'inicio') {
  const selected = pages[page] || pages.inicio;
  const target = document.querySelector('#page-content');
  if (!target) return;
  document.querySelector('#current-section').textContent = selected.title;
  target.innerHTML = `<div class="page-header"><div><span class="eyebrow">SISTEMA DE GESTÃO ESCOLAR</span><h1>${selected.title}</h1><p>${selected.subtitle}</p></div></div>${selected.content}`;
  document.querySelectorAll('[data-page]').forEach(item => item.classList.toggle('active', item.dataset.page === page));
}
