import '../css/styles.css';
import { renderShell } from './core/shell.js';
import { renderPage } from './core/router.js';

const app = document.querySelector('#app');
app.innerHTML = renderShell();
renderPage();

document.addEventListener('click', (event) => {
  const link = event.target.closest('[data-page]');
  if (!link) return;
  event.preventDefault();
  const page = link.dataset.page;
  history.pushState({ page }, '', `#${page}`);
  renderPage(page);
  document.querySelectorAll('[data-page]').forEach(item =>
    item.classList.toggle('active', item.dataset.page === page)
  );
  document.querySelector('.sidebar')?.classList.remove('open');
});

window.addEventListener('popstate', () => renderPage(location.hash.slice(1) || 'inicio'));

document.querySelector('[data-menu-toggle]')?.addEventListener('click', () => {
  document.querySelector('.sidebar')?.classList.toggle('open');
});
