# Modelagem de dados — rascunho

A modelagem definitiva será aprovada antes da migration inicial. Entidades candidatas:

- Instituição e perfis de usuário.
- Prédios, pisos, ambientes e laboratórios.
- Períodos, horários, reservas e decisões de aprovação.
- Ativos, computadores, periféricos e histórico de alocação.
- Inspeções e itens de checklist.
- Ocorrências, chamados e histórico de manutenção.
- Produtos, unidades de medida, locais de estoque e movimentações.
- Registros de software/atualização e trilha de auditoria.

As relações, cardinalidades, campos obrigatórios, exclusão lógica, integridade referencial, índices e RLS serão detalhados na etapa de banco de dados. Não criar tabelas de produção com base apenas nesta lista preliminar.
