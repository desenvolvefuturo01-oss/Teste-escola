const navGroups = [
  { title: 'PRINCIPAL', items: [['inicio','Início','⌂'], ['mapa','Mapa da escola','▦'], ['laboratorios','Laboratórios','▤'], ['agendamentos','Agendamentos','▣']] },
  { title: 'GESTÃO TÉCNICA', items: [['equipamentos','Equipamentos','▧'], ['inspecoes','Inspeções','✓'], ['manutencao','Manutenção','⚒'], ['estoque','Estoque','▤']] },
  { title: 'ADMINISTRAÇÃO', items: [['relatorios','Relatórios','▥'], ['usuarios','Usuários','♙'], ['configuracoes','Configurações','⚙']] }
];

export function renderShell() {
  return `
    <div class="app-layout">
      <aside class="sidebar">
        <div class="brand">
          <div class="brand-mark">S</div>
          <div><strong>SGLE</strong><small>Gestão de Laboratórios</small></div>
        </div>
        <nav aria-label="Menu principal">
          ${navGroups.map(group => `
            <div class="nav-group">
              <span class="nav-heading">${group.title}</span>
              ${group.items.map(([id,label,icon]) => `
                <a href="#${id}" data-page="${id}" class="nav-link ${id === 'inicio' ? 'active' : ''}">
                  <span class="nav-icon">${icon}</span><span>${label}</span>
                </a>`).join('')}
            </div>`).join('')}
        </nav>
        <div class="sidebar-bottom"><span class="status-dot"></span> Ambiente de desenvolvimento</div>
      </aside>
      <main class="main-area">
        <header class="topbar">
          <button class="menu-toggle" data-menu-toggle aria-label="Abrir menu">☰</button>
          <div class="breadcrumb">SGLE <span>/</span> <strong id="current-section">Início</strong></div>
          <div class="user-area"><div class="avatar">AD</div><div><strong>Administrador</strong><small>Perfil de demonstração</small></div></div>
        </header>
        <section id="page-content" class="page-content"></section>
        <footer class="footer">SGLE · Sistema de Gestão de Laboratórios Escolares <span>Versão 0.1.0 — ambiente inicial</span></footer>
      </main>
    </div>`;
}
