# Segurança e LGPD — diretrizes iniciais

- Coletar apenas dados necessários à operação escolar.
- Definir finalidade, acesso e prazo de retenção dos registros.
- Ativar RLS em todas as tabelas expostas pela API.
- Aplicar privilégio mínimo por perfil e validar autorização no banco.
- Nunca disponibilizar `service_role` no frontend ou no repositório.
- Manter segredos em variáveis de ambiente locais e configurações seguras de implantação.
- Registrar alterações relevantes sem armazenar senhas ou tokens nos logs.
- Planejar backup, restauração, revisão de acessos e resposta a incidentes.
- Validar a base legal, transparência e responsabilidades com a instituição antes da operação real.
