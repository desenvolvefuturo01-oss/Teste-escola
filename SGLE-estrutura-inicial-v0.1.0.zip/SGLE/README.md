# SGLE — Sistema de Gestão de Laboratórios Escolares

Projeto modular para gestão de laboratórios, agendamentos, equipamentos, inspeções, manutenção e estoque.

## Requisitos
- Node.js LTS
- npm

## Executar localmente
```bash
npm install
npm run dev
```

## Gerar build
```bash
npm run build
npm run preview
```

## Supabase
1. Crie um projeto Supabase para o ambiente de desenvolvimento.
2. Copie `.env.example` para `.env`.
3. Preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
4. Nunca use a chave `service_role` no frontend.
5. As migrations e políticas serão adicionadas em `supabase/` após aprovação da modelagem.

## Estado atual
Versão 0.1.0: estrutura inicial, navegação responsiva e páginas-base. Os módulos ainda são demonstrativos e não persistem dados.

Consulte `docs/` para requisitos, regras e decisões técnicas.
