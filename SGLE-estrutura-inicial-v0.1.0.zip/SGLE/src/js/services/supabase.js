// Cliente Supabase: será ativado após criar o projeto e configurar as variáveis locais.
// Nunca coloque a chave service_role no frontend.
import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = url && anonKey
  ? createClient(url, anonKey)
  : null;
