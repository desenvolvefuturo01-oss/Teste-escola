# Arquitetura técnica

## Visão geral
Aplicação web modular com HTML, CSS e JavaScript ES Modules, empacotada pelo Vite. Supabase fornecerá PostgreSQL, autenticação e APIs de dados.

## Camadas
- **Apresentação:** páginas, componentes e estilos responsivos.
- **Aplicação:** módulos e fluxos de negócio.
- **Serviços:** comunicação com Supabase e serviços externos autorizados.
- **Dados:** migrations SQL, constraints, índices, funções e políticas RLS.

## Princípios
1. Separar interface, regras de negócio e acesso a dados.
2. Validar permissões no banco, não apenas na interface.
3. Não incluir credenciais privilegiadas no navegador.
4. Usar migrations versionadas para alterações no banco.
5. Registrar decisões e testes relevantes.

## Ambiente
Requisitos locais: Node.js LTS e npm. Comandos: `npm install`, `npm run dev`, `npm run build`.

## Escopo institucional
A primeira implantação será preparada para uma escola, mantendo uma identificação institucional nos dados para permitir evolução futura sem misturar registros.
